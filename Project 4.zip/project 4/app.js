/* ============================================
   SMART STUDENT SKILL ANALYZER
   Core Application Engine
   ============================================ */

// ── Industry Requirement Database ──────────
const INDUSTRY_DATA = {
  domains: {
    'Data Science': {
      icon: '📊',
      color: '#6366f1',
      requiredSkills: {
        'Python': 9, 'SQL': 8, 'Statistics': 9, 'Machine Learning': 9,
        'Data Visualization': 8, 'Deep Learning': 7, 'R': 5, 'Excel': 6,
        'Big Data': 6, 'NLP': 6, 'Mathematics': 8, 'Probability': 8
      },
      keywords: ['data', 'ml', 'ai', 'analytics', 'statistics', 'machine learning',
                 'deep learning', 'neural', 'nlp', 'tensorflow', 'pytorch', 'pandas',
                 'numpy', 'scikit', 'regression', 'classification'],
      description: 'Extracting insights from data using statistical analysis and ML'
    },
    'Web Development': {
      icon: '🌐',
      color: '#38bdf8',
      requiredSkills: {
        'HTML/CSS': 9, 'JavaScript': 9, 'React': 8, 'Node.js': 8,
        'TypeScript': 7, 'SQL': 7, 'MongoDB': 6, 'Git': 8,
        'REST APIs': 8, 'CSS Frameworks': 7, 'Responsive Design': 8, 'Testing': 6
      },
      keywords: ['web', 'frontend', 'backend', 'fullstack', 'react', 'angular',
                 'vue', 'node', 'express', 'html', 'css', 'javascript', 'django',
                 'flask', 'api', 'rest', 'graphql'],
      description: 'Building responsive and scalable web applications'
    },
    'App Development': {
      icon: '📱',
      color: '#22c55e',
      requiredSkills: {
        'Java': 7, 'Kotlin': 8, 'Swift': 7, 'React Native': 7,
        'Flutter': 8, 'Dart': 7, 'UI/UX Design': 8, 'Firebase': 7,
        'REST APIs': 8, 'Git': 7, 'Testing': 6, 'SQLite': 6
      },
      keywords: ['mobile', 'android', 'ios', 'flutter', 'react native', 'app',
                 'kotlin', 'swift', 'dart', 'firebase', 'mobile app'],
      description: 'Creating mobile applications for iOS and Android platforms'
    },
    'Cybersecurity': {
      icon: '🔒',
      color: '#ef4444',
      requiredSkills: {
        'Networking': 9, 'Linux': 9, 'Python': 8, 'Ethical Hacking': 8,
        'Cryptography': 8, 'Security Tools': 8, 'Bash': 7, 'C/C++': 7,
        'Incident Response': 7, 'Forensics': 6, 'OWASP': 7, 'Firewalls': 7
      },
      keywords: ['security', 'hacking', 'penetration', 'vulnerability', 'firewall',
                 'encryption', 'malware', 'forensics', 'ctf', 'cyber', 'network security'],
      description: 'Protecting systems and networks from digital threats'
    },
    'Cloud & DevOps': {
      icon: '☁️',
      color: '#f59e0b',
      requiredSkills: {
        'Linux': 9, 'Docker': 9, 'Kubernetes': 8, 'AWS': 8,
        'CI/CD': 8, 'Terraform': 7, 'Python': 7, 'Bash': 8,
        'Networking': 7, 'Git': 9, 'Monitoring': 7, 'Jenkins': 6
      },
      keywords: ['cloud', 'devops', 'aws', 'azure', 'gcp', 'docker', 'kubernetes',
                 'terraform', 'ci/cd', 'jenkins', 'deployment', 'infrastructure'],
      description: 'Managing cloud infrastructure and deployment pipelines'
    },
    'AI & Robotics': {
      icon: '🤖',
      color: '#ec4899',
      requiredSkills: {
        'Python': 9, 'Machine Learning': 9, 'Deep Learning': 9, 'Mathematics': 9,
        'Computer Vision': 8, 'NLP': 7, 'C/C++': 7, 'ROS': 6,
        'Reinforcement Learning': 7, 'TensorFlow/PyTorch': 9, 'Linear Algebra': 9, 'Probability': 8
      },
      keywords: ['ai', 'artificial intelligence', 'robotics', 'computer vision', 'deep learning',
                 'neural network', 'reinforcement', 'autonomous', 'perception'],
      description: 'Building intelligent systems and autonomous machines'
    },
    'Game Development': {
      icon: '🎮',
      color: '#06b6d4',
      requiredSkills: {
        'C#': 8, 'C/C++': 8, 'Unity': 8, 'Unreal Engine': 7,
        '3D Math': 8, 'Game Design': 8, 'Physics': 7, 'Shaders': 6,
        'Animation': 6, 'Git': 7, 'Networking': 5, 'UI/UX Design': 6
      },
      keywords: ['game', 'unity', 'unreal', 'gaming', 'game design', 'game dev',
                 'shader', '3d', 'animation', 'physics engine'],
      description: 'Creating interactive gaming experiences'
    }
  },

  sectors: {
    'Product-Based (FAANG+)': {
      icon: '🚀', color: '#6366f1',
      traits: { dsa: 0.35, competitive: 0.25, projects: 0.2, academics: 0.2 },
      examples: 'Google, Microsoft, Amazon, Meta, Apple',
      description: 'Top-tier tech companies with innovative products'
    },
    'Startup': {
      icon: '💡', color: '#22c55e',
      traits: { projects: 0.35, skills_breadth: 0.25, hackathons: 0.2, initiative: 0.2 },
      examples: 'Y Combinator startups, funded ventures',
      description: 'Fast-paced, innovative early-stage companies'
    },
    'Service-Based': {
      icon: '🏢', color: '#38bdf8',
      traits: { academics: 0.35, skills_breadth: 0.25, communication: 0.2, dsa: 0.2 },
      examples: 'TCS, Infosys, Wipro, Cognizant',
      description: 'IT services and consulting companies'
    },
    'Research & Academia': {
      icon: '🔬', color: '#f59e0b',
      traits: { academics: 0.35, research: 0.3, depth: 0.2, publications: 0.15 },
      examples: 'IITs, DRDO, ISRO, Research Labs',
      description: 'Academic institutions and research organizations'
    },
    'Government & PSU': {
      icon: '🏛️', color: '#ef4444',
      traits: { academics: 0.4, aptitude: 0.25, general_knowledge: 0.2, discipline: 0.15 },
      examples: 'ISRO, DRDO, BSNL, BHEL',
      description: 'Government organizations and public sector units'
    },
    'Freelance & Remote': {
      icon: '🌍', color: '#ec4899',
      traits: { projects: 0.3, skills_breadth: 0.3, communication: 0.2, portfolio: 0.2 },
      examples: 'Upwork, Toptal, Fiverr, Remote.co',
      description: 'Independent freelancing and remote work opportunities'
    }
  },

  languages: [
    { name: 'Python', emoji: '🐍' },
    { name: 'JavaScript', emoji: '⚡' },
    { name: 'Java', emoji: '☕' },
    { name: 'C/C++', emoji: '⚙️' },
    { name: 'C#', emoji: '🎯' },
    { name: 'TypeScript', emoji: '📘' },
    { name: 'SQL', emoji: '🗄️' },
    { name: 'R', emoji: '📊' },
    { name: 'Kotlin', emoji: '🟣' },
    { name: 'Swift', emoji: '🍎' },
    { name: 'Go', emoji: '🔵' },
    { name: 'Rust', emoji: '🦀' },
    { name: 'PHP', emoji: '🐘' },
    { name: 'Ruby', emoji: '💎' },
    { name: 'Dart', emoji: '🎯' }
  ],

  interests: [
    { id: 'ai_ml', label: '🤖 AI & Machine Learning', domains: ['Data Science', 'AI & Robotics'] },
    { id: 'web_dev', label: '🌐 Web Development', domains: ['Web Development'] },
    { id: 'mobile', label: '📱 Mobile Apps', domains: ['App Development'] },
    { id: 'cybersec', label: '🔒 Cybersecurity', domains: ['Cybersecurity'] },
    { id: 'cloud', label: '☁️ Cloud & DevOps', domains: ['Cloud & DevOps'] },
    { id: 'data', label: '📈 Data Analytics', domains: ['Data Science'] },
    { id: 'game', label: '🎮 Game Development', domains: ['Game Development'] },
    { id: 'blockchain', label: '⛓️ Blockchain', domains: ['Web Development', 'Cybersecurity'] },
    { id: 'iot', label: '🔌 IoT', domains: ['AI & Robotics', 'Cloud & DevOps'] },
    { id: 'dsa', label: '🧩 Competitive Coding', domains: [] },
    { id: 'ui_ux', label: '🎨 UI/UX Design', domains: ['Web Development', 'App Development'] },
    { id: 'research', label: '🔬 Research', domains: ['Data Science', 'AI & Robotics'] }
  ]
};

// ── Roadmap Templates ──────────────────────
const ROADMAP_TEMPLATES = {
  'Data Science': [
    { month: 'Month 1', title: 'Foundations', skills: ['Python Basics', 'NumPy', 'Pandas', 'Statistics Fundamentals'] },
    { month: 'Month 2', title: 'Data Exploration', skills: ['EDA', 'Matplotlib', 'Seaborn', 'Data Cleaning'] },
    { month: 'Month 3', title: 'Machine Learning Basics', skills: ['Scikit-learn', 'Regression', 'Classification', 'Model Evaluation'] },
    { month: 'Month 4', title: 'Advanced ML', skills: ['Ensemble Methods', 'Feature Engineering', 'Hyperparameter Tuning', 'Cross-Validation'] },
    { month: 'Month 5', title: 'Deep Learning', skills: ['TensorFlow/PyTorch', 'Neural Networks', 'CNNs', 'NLP Basics'] },
    { month: 'Month 6', title: 'Projects & Portfolio', skills: ['Kaggle Competitions', 'End-to-End Project', 'Deployment (Flask/Streamlit)', 'Portfolio'] }
  ],
  'Web Development': [
    { month: 'Month 1', title: 'Frontend Foundations', skills: ['HTML5', 'CSS3', 'JavaScript ES6+', 'Responsive Design'] },
    { month: 'Month 2', title: 'React Ecosystem', skills: ['React.js', 'State Management', 'React Router', 'Hooks'] },
    { month: 'Month 3', title: 'Backend Development', skills: ['Node.js', 'Express.js', 'REST APIs', 'Authentication'] },
    { month: 'Month 4', title: 'Database & ORM', skills: ['MongoDB', 'PostgreSQL', 'Prisma/Mongoose', 'Redis'] },
    { month: 'Month 5', title: 'Advanced Concepts', skills: ['TypeScript', 'Next.js', 'GraphQL', 'Testing'] },
    { month: 'Month 6', title: 'DevOps & Deploy', skills: ['Docker', 'CI/CD', 'AWS/Vercel', 'Portfolio Projects'] }
  ],
  'App Development': [
    { month: 'Month 1', title: 'Mobile Foundations', skills: ['Dart Basics', 'Flutter Setup', 'Widgets', 'Layouts'] },
    { month: 'Month 2', title: 'Flutter Advanced', skills: ['State Management', 'Navigation', 'Animations', 'Custom Widgets'] },
    { month: 'Month 3', title: 'Backend Integration', skills: ['Firebase', 'REST APIs', 'Authentication', 'Cloud Storage'] },
    { month: 'Month 4', title: 'Native Development', skills: ['Kotlin (Android)', 'Platform Channels', 'Local Storage', 'Push Notifications'] },
    { month: 'Month 5', title: 'Advanced Features', skills: ['Maps & Location', 'Camera & Media', 'Payments', 'App Architecture'] },
    { month: 'Month 6', title: 'Publish & Portfolio', skills: ['App Store Deployment', 'Play Store Deployment', 'CI/CD', 'Portfolio'] }
  ],
  'Cybersecurity': [
    { month: 'Month 1', title: 'Foundations', skills: ['Linux Basics', 'Networking', 'TCP/IP', 'Wireshark'] },
    { month: 'Month 2', title: 'Security Fundamentals', skills: ['OWASP Top 10', 'Cryptography', 'Access Control', 'Security Policies'] },
    { month: 'Month 3', title: 'Offensive Security', skills: ['Kali Linux', 'Nmap', 'Metasploit', 'Burp Suite'] },
    { month: 'Month 4', title: 'Web App Security', skills: ['SQL Injection', 'XSS', 'CSRF', 'API Security'] },
    { month: 'Month 5', title: 'Advanced Topics', skills: ['Malware Analysis', 'Digital Forensics', 'Incident Response', 'SIEM'] },
    { month: 'Month 6', title: 'Certifications & CTF', skills: ['CEH Prep', 'CTF Competitions', 'Bug Bounty', 'Portfolio'] }
  ],
  'Cloud & DevOps': [
    { month: 'Month 1', title: 'Foundations', skills: ['Linux Administration', 'Bash Scripting', 'Networking', 'Git Advanced'] },
    { month: 'Month 2', title: 'Containers', skills: ['Docker', 'Docker Compose', 'Container Networking', 'Image Optimization'] },
    { month: 'Month 3', title: 'Cloud Platforms', skills: ['AWS Core Services', 'IAM', 'S3', 'EC2 & VPC'] },
    { month: 'Month 4', title: 'Orchestration', skills: ['Kubernetes', 'Helm Charts', 'Service Mesh', 'Monitoring'] },
    { month: 'Month 5', title: 'IaC & CI/CD', skills: ['Terraform', 'Ansible', 'Jenkins/GitLab CI', 'ArgoCD'] },
    { month: 'Month 6', title: 'Production Ready', skills: ['SRE Practices', 'Logging & Monitoring', 'Security', 'AWS Certification'] }
  ],
  'AI & Robotics': [
    { month: 'Month 1', title: 'Math & Python', skills: ['Linear Algebra', 'Calculus', 'Python', 'NumPy'] },
    { month: 'Month 2', title: 'ML Foundations', skills: ['Supervised Learning', 'Unsupervised Learning', 'Scikit-learn', 'Model Evaluation'] },
    { month: 'Month 3', title: 'Deep Learning', skills: ['PyTorch', 'CNNs', 'RNNs', 'Transfer Learning'] },
    { month: 'Month 4', title: 'Computer Vision', skills: ['OpenCV', 'Object Detection', 'Image Segmentation', 'GANs'] },
    { month: 'Month 5', title: 'NLP & RL', skills: ['Transformers', 'BERT/GPT', 'Reinforcement Learning', 'Robotics Basics'] },
    { month: 'Month 6', title: 'Projects & Research', skills: ['Research Paper Implementation', 'End-to-End Project', 'Model Deployment', 'Portfolio'] }
  ],
  'Game Development': [
    { month: 'Month 1', title: 'Foundations', skills: ['C# Basics', 'Unity Setup', 'Game Objects', '2D Physics'] },
    { month: 'Month 2', title: 'Game Mechanics', skills: ['Player Controllers', 'UI Systems', 'Animation', 'Audio'] },
    { month: 'Month 3', title: '3D Development', skills: ['3D Math', 'Lighting', 'Materials', 'Terrain'] },
    { month: 'Month 4', title: 'Advanced Unity', skills: ['Shaders', 'Particle Systems', 'AI Pathfinding', 'Multiplayer Basics'] },
    { month: 'Month 5', title: 'Polish & Optimization', skills: ['Performance Profiling', 'Mobile Optimization', 'Post-Processing', 'Level Design'] },
    { month: 'Month 6', title: 'Publish', skills: ['Steam/Itch.io', 'Marketing', 'Playtesting', 'Portfolio'] }
  ]
};


// ── Application State ──────────────────────
const state = {
  currentStep: 0,
  totalSteps: 5,
  currentUser: null,  // { email, name, role }
  formData: {
    name: '',
    cgpa: 0,
    year: '',
    skills: {},
    codingStats: { rating: 0, problemsSolved: 0, contests: 0, easyProblems: 0, mediumProblems: 0, hardProblems: 0 },
    interests: [],
    resumeSkills: [],
    githubUsername: '',
    githubData: null
  },
  results: null
};


// ── DOM Ready ──────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initWizard();
  initSkillSliders();
  initInterestTags();
  initFileUpload();
  initFormInputs();
  checkExistingSession();
});


// ── Wizard Navigation ─────────────────────
function initWizard() {
  showStep(0);
}

function showStep(index) {
  state.currentStep = index;

  // Update panels
  document.querySelectorAll('.wizard__panel').forEach((panel, i) => {
    panel.classList.toggle('active', i === index);
  });

  // Update dots
  document.querySelectorAll('.wizard__step-dot').forEach((dot, i) => {
    dot.classList.remove('active', 'completed');
    if (i === index) dot.classList.add('active');
    else if (i < index) dot.classList.add('completed');
  });

  // Update lines
  document.querySelectorAll('.wizard__step-line').forEach((line, i) => {
    line.classList.toggle('completed', i < index);
  });

  // Scroll to wizard
  if (index > 0) {
    document.getElementById('analyzer').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

function nextStep() {
  if (validateStep(state.currentStep)) {
    if (state.currentStep < state.totalSteps - 1) {
      saveStepData(state.currentStep);
      showStep(state.currentStep + 1);
    }
  }
}

function prevStep() {
  if (state.currentStep > 0) {
    showStep(state.currentStep - 1);
  }
}

function validateStep(stepIndex) {
  switch (stepIndex) {
    case 0: {
      const name = document.getElementById('studentName')?.value.trim();
      const cgpa = parseFloat(document.getElementById('cgpa')?.value);
      if (!name) { showToast('Please enter your name', 'error'); return false; }
      if (isNaN(cgpa) || cgpa < 0 || cgpa > 10) { showToast('Please enter a valid CGPA (0-10)', 'error'); return false; }
      return true;
    }
    case 1: return true; // Skills are optional
    case 2: return true; // Coding stats are optional
    case 3: {
      if (state.formData.interests.length === 0) {
        showToast('Please select at least one interest', 'error');
        return false;
      }
      return true;
    }
    case 4: return true;
    default: return true;
  }
}

function saveStepData(stepIndex) {
  switch (stepIndex) {
    case 0:
      state.formData.name = document.getElementById('studentName').value.trim();
      state.formData.cgpa = parseFloat(document.getElementById('cgpa').value) || 0;
      state.formData.year = document.getElementById('year').value;
      break;
    case 2:
      state.formData.codingStats = {
        rating: parseInt(document.getElementById('leetcodeRating')?.value) || 0,
        problemsSolved: parseInt(document.getElementById('problemsSolved')?.value) || 0,
        contests: parseInt(document.getElementById('contests')?.value) || 0,
        easyProblems: parseInt(document.getElementById('easyProblems')?.value) || 0,
        mediumProblems: parseInt(document.getElementById('mediumProblems')?.value) || 0,
        hardProblems: parseInt(document.getElementById('hardProblems')?.value) || 0
      };
      break;
  }
}

// ── Skill Sliders ─────────────────────────
function initSkillSliders() {
  document.querySelectorAll('.skill-slider').forEach(slider => {
    const valueEl = slider.closest('.skill-item').querySelector('.skill-item__value');
    slider.addEventListener('input', () => {
      valueEl.textContent = slider.value;
      const lang = slider.dataset.skill;
      state.formData.skills[lang] = parseInt(slider.value);
      updateSliderTrack(slider);
    });
    updateSliderTrack(slider);
  });
}

function updateSliderTrack(slider) {
  const pct = (slider.value / slider.max) * 100;
  slider.style.background = `linear-gradient(to right, #4f46e5 ${pct}%, #e2e8f0 ${pct}%)`;
}

// ── Interest Tags ─────────────────────────
function initInterestTags() {
  document.querySelectorAll('.interest-tag').forEach(tag => {
    tag.addEventListener('click', () => {
      tag.classList.toggle('selected');
      const id = tag.dataset.interest;
      if (tag.classList.contains('selected')) {
        if (!state.formData.interests.includes(id)) state.formData.interests.push(id);
      } else {
        state.formData.interests = state.formData.interests.filter(i => i !== id);
      }
    });
  });
}

// ── File Upload (Resume) ──────────────────
function initFileUpload() {
  const uploadArea = document.getElementById('resumeUpload');
  const fileInput = document.getElementById('resumeFile');
  if (!uploadArea || !fileInput) return;

  ['dragenter', 'dragover'].forEach(evt => {
    uploadArea.addEventListener(evt, e => { e.preventDefault(); uploadArea.classList.add('dragover'); });
  });
  ['dragleave', 'drop'].forEach(evt => {
    uploadArea.addEventListener(evt, e => { e.preventDefault(); uploadArea.classList.remove('dragover'); });
  });

  uploadArea.addEventListener('drop', e => {
    const file = e.dataTransfer.files[0];
    if (file) handleResumeFile(file);
  });

  fileInput.addEventListener('change', e => {
    const file = e.target.files[0];
    if (file) handleResumeFile(file);
  });
}

async function handleResumeFile(file) {
  if (file.type !== 'application/pdf') {
    showToast('Please upload a PDF file', 'error');
    return;
  }

  const uploadArea = document.getElementById('resumeUpload');
  uploadArea.classList.add('has-file');
  uploadArea.querySelector('.file-upload__text').textContent = file.name;
  uploadArea.querySelector('.file-upload__hint').textContent = 'Parsing skills from resume...';

  try {
    const text = await extractTextFromPDF(file);
    const skills = extractSkillsFromText(text);
    state.formData.resumeSkills = skills;
    uploadArea.querySelector('.file-upload__hint').textContent = `Found ${skills.length} skills: ${skills.slice(0, 5).join(', ')}${skills.length > 5 ? '...' : ''}`;
    showToast(`Extracted ${skills.length} skills from resume`, 'success');
  } catch (err) {
    uploadArea.querySelector('.file-upload__hint').textContent = 'Could not parse PDF. Skills will be analyzed from manual input.';
    showToast('PDF parsing failed. You can still proceed with manual input.', 'info');
  }
}

async function extractTextFromPDF(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async function(e) {
      try {
        if (typeof pdfjsLib !== 'undefined') {
          const typedArray = new Uint8Array(e.target.result);
          const pdf = await pdfjsLib.getDocument(typedArray).promise;
          let text = '';
          for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            const content = await page.getTextContent();
            text += content.items.map(item => item.str).join(' ') + '\n';
          }
          resolve(text);
        } else {
          reject(new Error('PDF.js not loaded'));
        }
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(file);
  });
}

function extractSkillsFromText(text) {
  const skillKeywords = [
    'python', 'java', 'javascript', 'c++', 'c#', 'typescript', 'sql', 'r',
    'kotlin', 'swift', 'go', 'rust', 'php', 'ruby', 'dart', 'scala',
    'html', 'css', 'react', 'angular', 'vue', 'node.js', 'express',
    'django', 'flask', 'spring', 'flutter', 'react native',
    'tensorflow', 'pytorch', 'scikit-learn', 'pandas', 'numpy',
    'docker', 'kubernetes', 'aws', 'azure', 'gcp', 'git',
    'mongodb', 'postgresql', 'mysql', 'redis', 'firebase',
    'machine learning', 'deep learning', 'nlp', 'computer vision',
    'data analysis', 'data visualization', 'statistics',
    'linux', 'networking', 'cybersecurity', 'ethical hacking',
    'unity', 'unreal engine', 'figma', 'photoshop',
    'agile', 'scrum', 'jira', 'rest api', 'graphql',
    'blockchain', 'solidity', 'web3'
  ];

  const lower = text.toLowerCase();
  return skillKeywords.filter(skill => lower.includes(skill))
    .map(s => s.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '));
}

// ── Form Inputs ───────────────────────────
function initFormInputs() {
  // GitHub username auto-fetch
  const ghInput = document.getElementById('githubUsername');
  if (ghInput) {
    let debounce;
    ghInput.addEventListener('input', () => {
      clearTimeout(debounce);
      state.formData.githubUsername = ghInput.value.trim();
      debounce = setTimeout(() => {
        if (state.formData.githubUsername.length > 2) {
          fetchGitHubData(state.formData.githubUsername);
        }
      }, 800);
    });
  }
}

// ── GitHub API ─────────────────────────────
async function fetchGitHubData(username) {
  const statusEl = document.getElementById('githubStatus');
  if (statusEl) statusEl.textContent = 'Fetching GitHub data...';

  try {
    const [userRes, reposRes] = await Promise.all([
      fetch(`https://api.github.com/users/${username}`),
      fetch(`https://api.github.com/users/${username}/repos?per_page=100&sort=updated`)
    ]);

    if (!userRes.ok) throw new Error('User not found');

    const user = await userRes.json();
    const repos = await reposRes.json();

    // Compute language distribution
    const langCount = {};
    let totalSize = 0;
    repos.forEach(repo => {
      if (repo.language) {
        langCount[repo.language] = (langCount[repo.language] || 0) + (repo.size || 1);
        totalSize += (repo.size || 1);
      }
    });

    const languages = {};
    Object.entries(langCount).forEach(([lang, size]) => {
      languages[lang] = Math.round((size / totalSize) * 100);
    });

    state.formData.githubData = {
      avatar: user.avatar_url,
      name: user.name || username,
      repos: user.public_repos,
      followers: user.followers,
      following: user.following,
      bio: user.bio,
      languages,
      totalStars: repos.reduce((sum, r) => sum + (r.stargazers_count || 0), 0),
      topRepos: repos.slice(0, 5).map(r => ({ name: r.name, language: r.language, stars: r.stargazers_count }))
    };

    if (statusEl) {
      statusEl.innerHTML = `<span style="color:var(--clr-success)">✓ Found: ${user.public_repos} repos, ${Object.keys(languages).length} languages</span>`;
    }
    showToast(`GitHub data loaded for ${username}`, 'success');
  } catch (err) {
    if (statusEl) {
      statusEl.innerHTML = `<span style="color:var(--clr-danger)">✗ ${err.message}</span>`;
    }
  }
}


// ═══════════════════════════════════════════
//  ANALYSIS ENGINES
// ═══════════════════════════════════════════

// ── Run Full Analysis ─────────────────────
async function runAnalysis() {
  saveStepData(state.currentStep);

  // Show analyzing overlay
  const overlay = document.getElementById('analyzingOverlay');
  overlay.classList.add('visible');

  const steps = [
    'Collecting input data...',
    'Computing feature vectors...',
    'Running domain classification...',
    'Analyzing language proficiency...',
    'Computing sector alignment...',
    'Performing skill gap analysis...',
    'Generating career roadmap...',
    'Building explanations...',
    'Rendering dashboard...'
  ];

  const stepEl = document.getElementById('analyzingStep');

  for (let i = 0; i < steps.length; i++) {
    stepEl.textContent = steps[i];
    await sleep(300 + Math.random() * 200);
  }

  // Check if student is a complete beginner
  const isBeginnerProfile = checkIfBeginner();

  // Run all engines
  const domainResults = predictDomain();
  const sectorResults = recommendSector();
  const languageResults = analyzeLanguages();
  const skillGaps = analyzeSkillGaps(domainResults[0].name);
  const roadmap = generateRoadmap(domainResults[0].name);
  const explanations = generateExplanations(domainResults, sectorResults);

  state.results = {
    domains: domainResults,
    sectors: sectorResults,
    languages: languageResults,
    skillGaps,
    roadmap,
    explanations,
    isBeginner: isBeginnerProfile
  };

  overlay.classList.remove('visible');

  // Save to localStorage
  saveToLocalStorage();

  // Render dashboard
  renderDashboard();
}


// ── 1. Domain Prediction Engine ───────────
function predictDomain() {
  const scores = {};

  Object.entries(INDUSTRY_DATA.domains).forEach(([domain, data]) => {
    let score = 0;
    let factors = 0;

    // Factor 1: Skill alignment (weight: 40%)
    let skillMatch = 0;
    let skillCount = 0;
    Object.entries(data.requiredSkills).forEach(([skill, req]) => {
      const userSkill = findSkillLevel(skill);
      if (userSkill > 0) {
        skillMatch += (userSkill / req) * 10;
        skillCount++;
      }
    });
    const skillScore = skillCount > 0 ? Math.min((skillMatch / skillCount) * 10, 100) : 0;
    score += skillScore * 0.40;
    factors++;

    // Factor 2: Interest alignment (weight: 30%)
    let interestMatch = 0;
    state.formData.interests.forEach(interest => {
      const interestData = INDUSTRY_DATA.interests.find(i => i.id === interest);
      if (interestData && interestData.domains.includes(domain)) {
        interestMatch += 25;
      }
    });
    score += Math.min(interestMatch, 100) * 0.30;

    // Factor 3: Coding pattern alignment (weight: 15%)
    const codingScore = computeCodingAlignment(domain);
    score += codingScore * 0.15;

    // Factor 4: Resume keyword match (weight: 10%)
    if (state.formData.resumeSkills.length > 0) {
      let keywordMatch = 0;
      state.formData.resumeSkills.forEach(skill => {
        if (data.keywords.some(kw => skill.toLowerCase().includes(kw))) {
          keywordMatch += 15;
        }
      });
      score += Math.min(keywordMatch, 100) * 0.10;
    } else {
      score += skillScore * 0.10; // Redistribute
    }

    // Factor 5: GitHub language alignment (weight: 5%)
    if (state.formData.githubData) {
      let ghScore = 0;
      const ghLangs = state.formData.githubData.languages;
      Object.keys(data.requiredSkills).forEach(skill => {
        if (ghLangs[skill]) ghScore += ghLangs[skill];
      });
      score += Math.min(ghScore, 100) * 0.05;
    } else {
      score += skillScore * 0.05;
    }

    scores[domain] = Math.round(Math.min(score, 98));
  });

  // Sort and return top domains
  const sorted = Object.entries(scores)
    .sort((a, b) => b[1] - a[1])
    .map(([name, confidence]) => ({
      name,
      confidence,
      icon: INDUSTRY_DATA.domains[name].icon,
      color: INDUSTRY_DATA.domains[name].color,
      description: INDUSTRY_DATA.domains[name].description
    }));

  // If all scores are 0 (beginner), assign based purely on interests
  if (sorted.every(d => d.confidence === 0)) {
    // Give interest-based domains a small boost, default to Web Dev
    state.formData.interests.forEach(interest => {
      const interestData = INDUSTRY_DATA.interests.find(i => i.id === interest);
      if (interestData) {
        interestData.domains.forEach(domain => {
          const found = sorted.find(d => d.name === domain);
          if (found) found.confidence = Math.max(found.confidence, 30 + Math.floor(Math.random() * 15));
        });
      }
    });
    // If still all zero, give Web Dev highest as default recommendation
    if (sorted.every(d => d.confidence === 0)) {
      sorted.find(d => d.name === 'Web Development').confidence = 35;
      sorted.find(d => d.name === 'Data Science').confidence = 25;
      sorted.find(d => d.name === 'App Development').confidence = 20;
    }
    sorted.sort((a, b) => b.confidence - a.confidence);
  }

  // Ensure minimum gap between first and others for clarity
  if (sorted.length > 1 && sorted[0].confidence - sorted[1].confidence < 5) {
    sorted[0].confidence = Math.min(sorted[0].confidence + 8, 98);
  }

  return sorted;
}

function findSkillLevel(skillName) {
  // Check manual skills
  const normalizedName = skillName.toLowerCase().replace(/\//g, '').replace(/\s+/g, '');
  for (const [key, value] of Object.entries(state.formData.skills)) {
    const normalizedKey = key.toLowerCase().replace(/\//g, '').replace(/\s+/g, '');
    if (normalizedKey.includes(normalizedName) || normalizedName.includes(normalizedKey)) {
      return value;
    }
  }

  // Check resume skills
  if (state.formData.resumeSkills.some(s => s.toLowerCase().includes(skillName.toLowerCase()))) {
    return 5; // Default level for resume-detected skills
  }

  return 0;
}

function computeCodingAlignment(domain) {
  const stats = state.formData.codingStats;
  const total = stats.problemsSolved || 0;
  const hard = stats.hardProblems || 0;
  const medium = stats.mediumProblems || 0;

  switch (domain) {
    case 'Data Science':
    case 'AI & Robotics':
      return Math.min(((stats.rating || 0) / 25) + (total / 10), 100);
    case 'Cybersecurity':
      return Math.min((total / 8) + (hard * 5), 100);
    case 'Web Development':
    case 'App Development':
      return Math.min((total / 6) + (medium * 2), 100);
    case 'Cloud & DevOps':
      return Math.min((total / 8) + (stats.rating / 20), 100);
    case 'Game Development':
      return Math.min((total / 10) + (hard * 3), 100);
    default:
      return Math.min(total / 5, 100);
  }
}


// ── 2. Sector Recommendation ──────────────
function recommendSector() {
  const results = [];

  const cgpa = state.formData.cgpa || 0;
  const stats = state.formData.codingStats;
  const skillValues = Object.values(state.formData.skills);
  const avgSkill = skillValues.length > 0 ? skillValues.reduce((a, b) => a + b, 0) / skillValues.length : 0;
  const maxSkill = skillValues.length > 0 ? Math.max(...skillValues) : 0;
  const skillBreadth = skillValues.filter(v => v >= 5).length;

  Object.entries(INDUSTRY_DATA.sectors).forEach(([name, sector]) => {
    let score = 0;

    // DSA / Competitive coding factor
    const dsaScore = Math.min(((stats.rating || 0) / 25) + ((stats.hardProblems || 0) * 3) + ((stats.mediumProblems || 0)), 100);

    // Academic factor
    const academicScore = Math.min(cgpa * 10, 100);

    // Projects factor (approximate from GitHub)
    const projectScore = state.formData.githubData
      ? Math.min(state.formData.githubData.repos * 5, 100)
      : Math.min(skillBreadth * 12, 100);

    // Skills breadth
    const breadthScore = Math.min(skillBreadth * 12, 100);

    // Calculate using sector-specific trait weights
    const t = sector.traits;
    score += (t.dsa || 0) * dsaScore;
    score += (t.competitive || 0) * dsaScore;
    score += (t.academics || 0) * academicScore;
    score += (t.projects || 0) * projectScore;
    score += (t.skills_breadth || 0) * breadthScore;
    score += (t.research || 0) * ((academicScore + avgSkill * 8) / 2);
    score += (t.hackathons || 0) * Math.min((stats.contests || 0) * 10, 100);
    score += (t.communication || 0) * 60; // Default
    score += (t.depth || 0) * (maxSkill * 10);
    score += (t.publications || 0) * 30; // Default
    score += (t.initiative || 0) * Math.min(projectScore + (stats.contests || 0) * 5, 100);
    score += (t.aptitude || 0) * ((academicScore + dsaScore) / 2);
    score += (t.general_knowledge || 0) * 50; // Default
    score += (t.discipline || 0) * academicScore;
    score += (t.portfolio || 0) * projectScore;

    results.push({
      name,
      score: Math.round(Math.min(score, 98)),
      icon: sector.icon,
      color: sector.color,
      examples: sector.examples,
      description: sector.description
    });
  });

  return results.sort((a, b) => b.score - a.score);
}


// ── 3. Language Depth Analyzer ────────────
function analyzeLanguages() {
  const results = [];

  INDUSTRY_DATA.languages.forEach(lang => {
    const manualLevel = state.formData.skills[lang.name] || 0;
    let githubPct = 0;
    if (state.formData.githubData && state.formData.githubData.languages) {
      githubPct = state.formData.githubData.languages[lang.name] || 0;
    }
    const resumeBonus = state.formData.resumeSkills.some(s =>
      s.toLowerCase().includes(lang.name.toLowerCase())
    ) ? 10 : 0;

    // Composite score: manual (60%) + GitHub (25%) + resume (15%)
    const composite = Math.round(
      manualLevel * 6 +           // 0-60
      githubPct * 0.25 +          // 0-25
      resumeBonus * 1.5           // 0-15
    );

    const score = Math.min(composite, 100);

    if (score > 0) {
      let level;
      if (score >= 80) level = 'Expert';
      else if (score >= 60) level = 'Advanced';
      else if (score >= 35) level = 'Intermediate';
      else level = 'Beginner';

      results.push({
        name: lang.name,
        emoji: lang.emoji,
        score,
        level,
        levelClass: level.toLowerCase()
      });
    }
  });

  return results.sort((a, b) => b.score - a.score);
}


// ── 4. Skill Gap Analyzer ─────────────────
function analyzeSkillGaps(primaryDomain) {
  const domainData = INDUSTRY_DATA.domains[primaryDomain];
  if (!domainData) return [];

  const gaps = [];

  Object.entries(domainData.requiredSkills).forEach(([skill, required]) => {
    const current = findSkillLevel(skill);
    const gap = required - current;

    if (gap > 2) {
      let priority;
      if (gap >= 7) priority = 'critical';
      else if (gap >= 4) priority = 'moderate';
      else priority = 'minor';

      gaps.push({ skill, required, current, gap, priority });
    }
  });

  return gaps.sort((a, b) => b.gap - a.gap);
}


// ── 5. Roadmap Generator ──────────────────
function generateRoadmap(domain) {
  return ROADMAP_TEMPLATES[domain] || ROADMAP_TEMPLATES['Web Development'];
}


// ── 6. Explainable AI ─────────────────────
function generateExplanations(domains, sectors) {
  const topDomain = domains[0];
  const domainData = INDUSTRY_DATA.domains[topDomain.name];
  const explanations = [];

  // Skill factors
  const skillFactors = {};
  Object.entries(domainData.requiredSkills).forEach(([skill, req]) => {
    const level = findSkillLevel(skill);
    if (level > 0) {
      skillFactors[skill] = Math.round((level / req) * 100);
    }
  });

  // Top contributing skills
  const topSkills = Object.entries(skillFactors)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  topSkills.forEach(([skill, contribution]) => {
    explanations.push({
      factor: skill,
      contribution: Math.min(contribution, 100),
      type: 'skill'
    });
  });

  // Interest alignment
  let interestContrib = 0;
  state.formData.interests.forEach(interest => {
    const interestData = INDUSTRY_DATA.interests.find(i => i.id === interest);
    if (interestData && interestData.domains.includes(topDomain.name)) {
      interestContrib += 30;
    }
  });
  explanations.push({
    factor: 'Interest Match',
    contribution: Math.min(interestContrib, 100),
    type: 'interest'
  });

  // Coding pattern
  const codingContrib = computeCodingAlignment(topDomain.name);
  explanations.push({
    factor: 'Coding Pattern',
    contribution: Math.round(codingContrib),
    type: 'coding'
  });

  // Academics
  explanations.push({
    factor: 'Academic CGPA',
    contribution: Math.min(Math.round(state.formData.cgpa * 10), 100),
    type: 'academic'
  });

  return explanations.sort((a, b) => b.contribution - a.contribution);
}


// ═══════════════════════════════════════════
//  DASHBOARD RENDERING
// ═══════════════════════════════════════════

function renderDashboard() {
  const r = state.results;

  // Hide form, show dashboard
  document.getElementById('analyzerSection').style.display = 'none';
  document.getElementById('heroSection').style.display = 'none';
  const dashboard = document.getElementById('dashboard');
  dashboard.classList.add('visible');
  dashboard.scrollIntoView({ behavior: 'smooth' });

  // Welcome message
  document.getElementById('dashboardName').textContent = state.formData.name;

  // Domain prediction
  renderDomainPrediction(r.domains);

  // Sector recommendation
  renderSectorRecommendation(r.sectors);

  // Language depth
  renderLanguageDepth(r.languages);

  // Skill radar chart
  renderSkillRadar();

  // Domain confidence chart
  renderDomainChart(r.domains);

  // Skill gaps
  renderSkillGaps(r.skillGaps);

  // Beginner guidance (if no skills at all)
  if (r.isBeginner) {
    renderBeginnerGuidance();
  } else {
    document.getElementById('beginnerGuidance').innerHTML = '';
  }

  // Roadmap
  renderRoadmap(r.roadmap);

  // Explainable AI
  renderExplanations(r.explanations, r.domains[0]);

  // GitHub stats (if available)
  renderGitHubStats();

  // Stats row
  renderStatsRow(r);

  // Trigger chart animations after render
  setTimeout(() => animateCharts(), 300);
}

function renderDomainPrediction(domains) {
  const container = document.getElementById('domainPrediction');
  const top = domains[0];

  container.innerHTML = `
    <div class="prediction-card prediction-card--primary">
      <div class="prediction-card__label">🎯 Recommended Domain</div>
      <div class="prediction-card__value">${top.icon} ${top.name}</div>
      <div class="prediction-card__confidence">
        <div class="confidence-bar">
          <div class="confidence-bar__fill" data-width="${top.confidence}%"></div>
        </div>
        <span class="confidence-text">${top.confidence}%</span>
      </div>
      <p style="font-size:0.9rem; color:var(--txt-secondary); margin-bottom:var(--space-md);">${top.description}</p>
      <div class="domain-tags">
        ${domains.slice(1, 4).map(d => `
          <div class="domain-tag">
            <span>${d.icon} ${d.name}</span>
            <span class="domain-tag__pct">${d.confidence}%</span>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function renderSectorRecommendation(sectors) {
  const container = document.getElementById('sectorRecommendation');
  container.innerHTML = `
    <div class="chart-card">
      <div class="chart-card__title">🏢 Sector Recommendations</div>
      <div class="chart-card__subtitle">Based on your profile analysis</div>
      ${sectors.slice(0, 4).map(s => `
        <div class="sector-card">
          <div class="sector-card__icon">${s.icon}</div>
          <div class="sector-card__info">
            <div class="sector-card__name">${s.name}</div>
            <div class="sector-card__reason">${s.examples}</div>
          </div>
          <div class="sector-card__match">${s.score}%</div>
        </div>
      `).join('')}
    </div>
  `;
}

function renderLanguageDepth(languages) {
  const container = document.getElementById('languageDepth');
  if (languages.length === 0) {
    container.innerHTML = `
      <div class="chart-card">
        <div class="chart-card__title">💻 Language Proficiency</div>
        <div class="chart-card__subtitle">No language data available - rate your skills to see analysis</div>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <div class="chart-card">
      <div class="chart-card__title">💻 Language Proficiency</div>
      <div class="chart-card__subtitle">Composite score from self-rating, GitHub, and resume</div>
      <div class="lang-bar-list">
        ${languages.slice(0, 8).map(l => `
          <div class="lang-bar">
            <div class="lang-bar__name">${l.emoji} ${l.name}</div>
            <div class="lang-bar__track">
              <div class="lang-bar__fill lang-bar__fill--${l.levelClass}" data-width="${l.score}%">
                <span class="lang-bar__level">${l.level}</span>
              </div>
            </div>
            <div class="lang-bar__pct">${l.score}%</div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function renderSkillRadar() {
  const container = document.getElementById('skillRadar');
  container.innerHTML = `
    <div class="chart-card">
      <div class="chart-card__title">📊 Skill Distribution</div>
      <div class="chart-card__subtitle">Your skills mapped across categories</div>
      <div class="chart-wrapper">
        <canvas id="radarChart"></canvas>
      </div>
    </div>
  `;

  // Categorize skills
  const categories = {
    'Programming': ['Python', 'JavaScript', 'Java', 'C/C++', 'C#', 'TypeScript'],
    'Data & ML': ['SQL', 'R', 'Statistics', 'Machine Learning', 'Data Visualization'],
    'Web Tech': ['HTML/CSS', 'React', 'Node.js', 'REST APIs', 'CSS Frameworks'],
    'DevOps': ['Docker', 'Linux', 'Git', 'AWS', 'CI/CD'],
    'Mobile': ['Kotlin', 'Swift', 'Flutter', 'Dart', 'React Native'],
    'Soft Skills': ['UI/UX Design', 'Testing', 'Agile', 'Communication']
  };

  const catScores = {};
  Object.entries(categories).forEach(([cat, skills]) => {
    let total = 0;
    let count = 0;
    skills.forEach(s => {
      const level = findSkillLevel(s);
      if (level > 0) { total += level; count++; }
    });
    catScores[cat] = count > 0 ? Math.round((total / count) * 10) : 0;
  });

  const ctx = document.getElementById('radarChart').getContext('2d');
  new Chart(ctx, {
    type: 'radar',
    data: {
      labels: Object.keys(catScores),
      datasets: [{
        label: 'Your Skills',
        data: Object.values(catScores),
        backgroundColor: 'rgba(79, 70, 229, 0.1)',
        borderColor: '#4f46e5',
        borderWidth: 2,
        pointBackgroundColor: '#4f46e5',
        pointBorderColor: '#6366f1',
        pointRadius: 5,
        pointHoverRadius: 7
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      scales: {
        r: {
          beginAtZero: true,
          max: 100,
          ticks: {
            stepSize: 20,
            color: '#94a3b8',
            backdropColor: 'transparent',
            font: { family: 'JetBrains Mono', size: 10 }
          },
          grid: { color: 'rgba(0,0,0,0.06)' },
          angleLines: { color: 'rgba(0,0,0,0.06)' },
          pointLabels: {
            color: '#475569',
            font: { family: 'Inter', size: 12, weight: '600' }
          }
        }
      },
      plugins: {
        legend: { display: false }
      },
      animation: {
        duration: 1500,
        easing: 'easeOutQuart'
      }
    }
  });
}

function renderDomainChart(domains) {
  const container = document.getElementById('domainChart');
  container.innerHTML = `
    <div class="chart-card">
      <div class="chart-card__title">🎯 Domain Confidence</div>
      <div class="chart-card__subtitle">Prediction confidence across all domains</div>
      <div class="chart-wrapper">
        <canvas id="doughnutChart"></canvas>
      </div>
    </div>
  `;

  const top5 = domains.slice(0, 5);
  const ctx = document.getElementById('doughnutChart').getContext('2d');
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: top5.map(d => d.name),
      datasets: [{
        data: top5.map(d => d.confidence),
        backgroundColor: top5.map(d => d.color + '40'),
        borderColor: top5.map(d => d.color),
        borderWidth: 2,
        hoverOffset: 8
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      cutout: '60%',
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: '#475569',
            padding: 16,
            font: { family: 'Inter', size: 12 },
            usePointStyle: true
          }
        }
      },
      animation: {
        animateRotate: true,
        animateScale: true,
        duration: 1500,
        easing: 'easeOutQuart'
      }
    }
  });
}

function renderSkillGaps(gaps) {
  const container = document.getElementById('skillGaps');
  if (gaps.length === 0) {
    container.innerHTML = `
      <div class="chart-card full-width">
        <div class="chart-card__title">📉 Skill Gap Analysis</div>
        <div style="text-align:center; padding:var(--space-xl); color:var(--clr-success);">
          <div style="font-size:2rem; margin-bottom:var(--space-sm);">🎉</div>
          <p>Great job! No significant skill gaps detected for your target domain.</p>
        </div>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <div class="chart-card full-width">
      <div class="chart-card__title">📉 Skill Gap Analysis</div>
      <div class="chart-card__subtitle">Skills you need to develop for ${state.results.domains[0].name}</div>
      <div class="gap-list anim-stagger">
        ${gaps.slice(0, 8).map(g => `
          <div class="gap-item gap-item--${g.priority}">
            <div class="gap-item__skill">
              ${g.skill}
              <div style="font-size:0.75rem; color:var(--txt-muted); margin-top:2px;">
                Current: ${g.current}/10 → Required: ${g.required}/10
              </div>
            </div>
            <div class="gap-item__priority">${g.priority}</div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function renderRoadmap(roadmap) {
  const container = document.getElementById('roadmapSection');
  container.innerHTML = `
    <div class="chart-card full-width">
      <div class="chart-card__title">📚 6-Month Learning Roadmap</div>
      <div class="chart-card__subtitle">Your personalized path to ${state.results.domains[0].name}</div>
      <div class="roadmap anim-stagger">
        ${roadmap.map(item => `
          <div class="roadmap__item">
            <div class="roadmap__month">${item.month}</div>
            <div class="roadmap__title">${item.title}</div>
            <div class="roadmap__skills">
              ${item.skills.map(s => `<span class="roadmap__skill-tag">${s}</span>`).join('')}
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function renderExplanations(explanations, topDomain) {
  const container = document.getElementById('explainSection');
  container.innerHTML = `
    <div class="explain-card full-width">
      <div class="chart-card__title">🧠 Why ${topDomain.name}?</div>
      <div class="chart-card__subtitle">Explainable AI — Understanding the prediction factors</div>
      <div style="margin-top:var(--space-lg);">
        ${explanations.slice(0, 8).map(e => `
          <div class="explain-factor">
            <div class="explain-factor__label">${e.factor}</div>
            <div class="explain-factor__bar">
              <div class="explain-factor__fill" data-width="${e.contribution}%"></div>
            </div>
            <div class="explain-factor__value">${e.contribution}%</div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

function renderGitHubStats() {
  const container = document.getElementById('githubSection');
  if (!state.formData.githubData) {
    container.innerHTML = '';
    return;
  }

  const gh = state.formData.githubData;
  container.innerHTML = `
    <div class="chart-card full-width">
      <div class="chart-card__title">🐙 GitHub Analysis</div>
      <div class="chart-card__subtitle">Real coding activity from ${gh.name}'s GitHub profile</div>
      <div class="github-stats" style="margin-top:var(--space-lg);">
        <div class="github-stat">
          <div class="github-stat__value">${gh.repos}</div>
          <div class="github-stat__label">Repositories</div>
        </div>
        <div class="github-stat">
          <div class="github-stat__value">${gh.totalStars}</div>
          <div class="github-stat__label">Total Stars</div>
        </div>
        <div class="github-stat">
          <div class="github-stat__value">${gh.followers}</div>
          <div class="github-stat__label">Followers</div>
        </div>
        <div class="github-stat">
          <div class="github-stat__value">${Object.keys(gh.languages).length}</div>
          <div class="github-stat__label">Languages</div>
        </div>
      </div>
      ${gh.topRepos && gh.topRepos.length > 0 ? `
        <div style="margin-top:var(--space-xl);">
          <h4 style="font-size:0.9rem; color:var(--txt-muted); margin-bottom:var(--space-md);">Top Repositories</h4>
          ${gh.topRepos.map(r => `
            <div class="sector-card" style="margin-bottom:var(--space-sm);">
              <div class="sector-card__icon">📦</div>
              <div class="sector-card__info">
                <div class="sector-card__name">${r.name}</div>
                <div class="sector-card__reason">${r.language || 'Unknown'}</div>
              </div>
              <div class="sector-card__match">⭐ ${r.stars}</div>
            </div>
          `).join('')}
        </div>
      ` : ''}
    </div>
  `;
}

function renderStatsRow(results) {
  const container = document.getElementById('statsRow');
  const strongest = results.languages[0];
  const weakCount = results.skillGaps.filter(g => g.priority === 'critical').length;

  container.innerHTML = `
    <div class="stat-card">
      <div class="stat-card__icon">🎯</div>
      <div class="stat-card__value" style="background:var(--grad-primary);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">${results.domains[0].name.split(' ')[0]}</div>
      <div class="stat-card__label">Predicted Domain</div>
    </div>
    <div class="stat-card">
      <div class="stat-card__icon">🏢</div>
      <div class="stat-card__value" style="color:var(--clr-success);">${results.sectors[0].score}%</div>
      <div class="stat-card__label">${results.sectors[0].name.split('(')[0].trim()}</div>
    </div>
    <div class="stat-card">
      <div class="stat-card__icon">💻</div>
      <div class="stat-card__value" style="color:var(--clr-accent);">${strongest ? strongest.name : 'N/A'}</div>
      <div class="stat-card__label">Strongest Language</div>
    </div>
    <div class="stat-card">
      <div class="stat-card__icon">📉</div>
      <div class="stat-card__value" style="color:${weakCount > 3 ? 'var(--clr-danger)' : 'var(--clr-warning)'};">${weakCount}</div>
      <div class="stat-card__label">Critical Skill Gaps</div>
    </div>
  `;
}

// ── Animate Charts on Render ──────────────
function animateCharts() {
  // Animate confidence bars
  document.querySelectorAll('.confidence-bar__fill').forEach(bar => {
    bar.style.width = bar.dataset.width;
  });

  // Animate language bars
  document.querySelectorAll('.lang-bar__fill').forEach(bar => {
    bar.style.width = bar.dataset.width;
  });

  // Animate explain bars
  document.querySelectorAll('.explain-factor__fill').forEach(bar => {
    bar.style.width = bar.dataset.width;
  });
}


// ── Reset & Re-analyze ───────────────────
function resetAnalysis() {
  document.getElementById('dashboard').classList.remove('visible');
  document.getElementById('analyzerSection').style.display = '';
  document.getElementById('heroSection').style.display = '';
  showStep(0);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}


// ── Utility Functions ─────────────────────
function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function showToast(message, type = 'info') {
  // Remove existing toast
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = `toast toast--${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  requestAnimationFrame(() => {
    toast.classList.add('visible');
  });

  setTimeout(() => {
    toast.classList.remove('visible');
    setTimeout(() => toast.remove(), 400);
  }, 3500);
}

// ── Scroll to Section ─────────────────────
function scrollToAnalyzer() {
  document.getElementById('analyzer').scrollIntoView({ behavior: 'smooth' });
}

// ── Export Results as PDF (simple print) ──
function exportResults() {
  window.print();
}

// ── Particles Background — REMOVED for cleaner UI ──


// ═══════════════════════════════════════════
//  BEGINNER DETECTION & HANDLING
// ═══════════════════════════════════════════

function checkIfBeginner() {
  const skillValues = Object.values(state.formData.skills);
  const totalSkill = skillValues.reduce((a, b) => a + b, 0);
  const stats = state.formData.codingStats;
  const totalCoding = (stats.rating || 0) + (stats.problemsSolved || 0);
  const hasResume = state.formData.resumeSkills.length > 0;
  const hasGitHub = !!state.formData.githubData;

  return totalSkill === 0 && totalCoding === 0 && !hasResume && !hasGitHub;
}

function renderBeginnerGuidance() {
  const container = document.getElementById('beginnerGuidance');
  if (!container) return;

  container.innerHTML = `
    <div class="chart-card full-width" style="border-color: var(--clr-warning); border-width: 2px;">
      <div class="chart-card__title">🌱 You're Just Getting Started — That's Great!</div>
      <div class="chart-card__subtitle" style="margin-bottom: var(--space-lg);">
        We noticed you haven't rated any skills yet. No worries! Here's what we recommend for absolute beginners:
      </div>
      
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: var(--space-lg);">
        <div style="background: var(--bg-secondary); padding: var(--space-lg); border-radius: var(--border-radius-sm); border-left: 3px solid var(--clr-primary);">
          <h4 style="margin-bottom: var(--space-sm);">📌 Step 1: Pick ONE Language</h4>
          <p style="font-size: 0.9rem; color: var(--txt-secondary);">Start with <strong>Python</strong> — it's beginner-friendly, versatile, and used in Data Science, Web, AI, and Automation.</p>
        </div>
        
        <div style="background: var(--bg-secondary); padding: var(--space-lg); border-radius: var(--border-radius-sm); border-left: 3px solid var(--clr-accent);">
          <h4 style="margin-bottom: var(--space-sm);">📌 Step 2: Build Basics (Week 1-4)</h4>
          <p style="font-size: 0.9rem; color: var(--txt-secondary);">Learn variables, loops, functions, and basic data structures. Use free platforms like <strong>freeCodeCamp</strong> or <strong>CS50</strong>.</p>
        </div>
        
        <div style="background: var(--bg-secondary); padding: var(--space-lg); border-radius: var(--border-radius-sm); border-left: 3px solid var(--clr-success);">
          <h4 style="margin-bottom: var(--space-sm);">📌 Step 3: Solve Problems (Week 5-8)</h4>
          <p style="font-size: 0.9rem; color: var(--txt-secondary);">Start solving easy problems on <strong>LeetCode</strong> or <strong>HackerRank</strong>. Aim for 2-3 problems per day.</p>
        </div>
        
        <div style="background: var(--bg-secondary); padding: var(--space-lg); border-radius: var(--border-radius-sm); border-left: 3px solid var(--clr-warning);">
          <h4 style="margin-bottom: var(--space-sm);">📌 Step 4: Build a Project (Week 9-12)</h4>
          <p style="font-size: 0.9rem; color: var(--txt-secondary);">Create a small project (calculator, to-do app, simple website). Push it to <strong>GitHub</strong> to start your portfolio.</p>
        </div>
        
        <div style="background: var(--bg-secondary); padding: var(--space-lg); border-radius: var(--border-radius-sm); border-left: 3px solid #ec4899;">
          <h4 style="margin-bottom: var(--space-sm);">📌 Step 5: Explore Domains (Month 3+)</h4>
          <p style="font-size: 0.9rem; color: var(--txt-secondary);">Try different areas based on your interests. The domain prediction above is based on your selected interests — come back and re-analyze after building skills!</p>
        </div>
        
        <div style="background: var(--bg-secondary); padding: var(--space-lg); border-radius: var(--border-radius-sm); border-left: 3px solid #f59e0b;">
          <h4 style="margin-bottom: var(--space-sm);">🎯 Free Resources to Start</h4>
          <ul style="font-size: 0.85rem; color: var(--txt-secondary); list-style: none; display:flex; flex-direction:column; gap: 6px;">
            <li>▸ <strong>Python:</strong> python.org, Automate the Boring Stuff</li>
            <li>▸ <strong>Web Dev:</strong> freeCodeCamp, The Odin Project</li>
            <li>▸ <strong>DSA:</strong> LeetCode, GeeksForGeeks, NeetCode</li>
            <li>▸ <strong>CS Basics:</strong> Harvard CS50 (free on YouTube)</li>
            <li>▸ <strong>Projects:</strong> GitHub Student Pack (free tools)</li>
          </ul>
        </div>
      </div>
    </div>
  `;
}


// ═══════════════════════════════════════════
//  AUTHENTICATION SYSTEM
// ═══════════════════════════════════════════

const USERS_KEY = 'careerpath_users';
const RECORDS_KEY = 'careerpath_student_records';
const SESSION_KEY = 'careerpath_session';
const ADMIN_CREDENTIALS = { username: 'admin', password: 'admin123' };

// ── Role Selection ────────────────────────
function selectRole(role) {
  document.getElementById('roleStudentBtn').classList.toggle('role-btn--active', role === 'student');
  document.getElementById('roleAdminBtn').classList.toggle('role-btn--active', role === 'admin');
  document.getElementById('studentAuthPanel').style.display = role === 'student' ? 'block' : 'none';
  document.getElementById('adminAuthPanel').style.display = role === 'admin' ? 'block' : 'none';
}

// ── Auth Tab Switch ───────────────────────
function switchAuthTab(panel, tab) {
  if (panel === 'student') {
    document.getElementById('studentLoginTab').classList.toggle('auth-tab--active', tab === 'login');
    document.getElementById('studentRegisterTab').classList.toggle('auth-tab--active', tab === 'register');
    document.getElementById('studentLoginForm').style.display = tab === 'login' ? 'flex' : 'none';
    document.getElementById('studentRegisterForm').style.display = tab === 'register' ? 'flex' : 'none';
  }
}

// ── Student Registration ──────────────────
function handleStudentRegister(e) {
  e.preventDefault();
  const name = document.getElementById('studentRegName').value.trim();
  const email = document.getElementById('studentRegEmail').value.trim().toLowerCase();
  const password = document.getElementById('studentRegPassword').value;

  if (!name || !email || password.length < 4) {
    showToast('Please fill all fields (password min 4 chars)', 'error');
    return false;
  }

  const users = getUsers();
  if (users.find(u => u.email === email)) {
    showToast('This email is already registered. Please login.', 'error');
    return false;
  }

  users.push({ name, email, password, createdAt: new Date().toISOString() });
  localStorage.setItem(USERS_KEY, JSON.stringify(users));

  showToast('Account created! Please login.', 'success');
  switchAuthTab('student', 'login');
  document.getElementById('studentLoginEmail').value = email;
  document.getElementById('studentRegisterForm').reset();
  return false;
}

// ── Student Login ─────────────────────────
function handleStudentLogin(e) {
  e.preventDefault();
  const email = document.getElementById('studentLoginEmail').value.trim().toLowerCase();
  const password = document.getElementById('studentLoginPassword').value;

  const users = getUsers();
  const user = users.find(u => u.email === email && u.password === password);

  if (!user) {
    showToast('Invalid email or password', 'error');
    return false;
  }

  const session = { email: user.email, name: user.name, role: 'student' };
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  state.currentUser = session;
  enterStudentMode(user.name);
  showToast(`Welcome back, ${user.name}!`, 'success');
  return false;
}

// ── Admin Login ───────────────────────────
function handleAdminLogin(e) {
  e.preventDefault();
  const username = document.getElementById('adminLoginUser').value.trim();
  const password = document.getElementById('adminLoginPassword').value;

  if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
    const session = { email: 'admin', name: 'Admin', role: 'admin' };
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    state.currentUser = session;
    enterAdminMode();
    showToast('Welcome, Admin!', 'success');
  } else {
    showToast('Invalid admin credentials', 'error');
  }
  return false;
}

// ── Session Check ─────────────────────────
function checkExistingSession() {
  try {
    const session = JSON.parse(localStorage.getItem(SESSION_KEY));
    if (session && session.role) {
      state.currentUser = session;
      if (session.role === 'admin') {
        enterAdminMode();
      } else {
        enterStudentMode(session.name);
      }
      return;
    }
  } catch {}
  // No session — show login
  showLoginPage();
}

// ── Logout ────────────────────────────────
function handleLogout() {
  localStorage.removeItem(SESSION_KEY);
  state.currentUser = null;
  document.body.classList.remove('logged-in');
  document.getElementById('navbar').style.display = 'none';
  document.getElementById('heroSection').style.display = 'none';
  document.getElementById('analyzer').style.display = 'none';
  document.getElementById('dashboard').classList.remove('visible');
  document.getElementById('adminPanel').style.display = 'none';
  showLoginPage();
  showToast('Logged out', 'info');
}

// ── Show Login Page ───────────────────────
function showLoginPage() {
  document.getElementById('loginSection').style.display = '';
  document.getElementById('heroSection').style.display = 'none';
  document.getElementById('analyzer').style.display = 'none';
  document.getElementById('navbar').style.display = 'none';
  document.getElementById('adminPanel').style.display = 'none';
  document.body.classList.remove('logged-in');
}

// ── Enter Student Mode ────────────────────
function enterStudentMode(name) {
  document.getElementById('loginSection').style.display = 'none';
  document.getElementById('heroSection').style.display = '';
  document.getElementById('analyzer').style.display = '';
  document.getElementById('adminPanel').style.display = 'none';
  document.getElementById('navbar').style.display = '';
  document.getElementById('navbarUser').textContent = '🎒 ' + name;
  document.body.classList.add('logged-in');

  // Pre-fill name field
  const nameInput = document.getElementById('studentName');
  if (nameInput && !nameInput.value) {
    nameInput.value = name;
  }
}

// ── Enter Admin Mode ──────────────────────
function enterAdminMode() {
  document.getElementById('loginSection').style.display = 'none';
  document.getElementById('heroSection').style.display = 'none';
  document.getElementById('analyzer').style.display = 'none';
  document.getElementById('dashboard').classList.remove('visible');
  document.getElementById('adminPanel').style.display = '';
  document.getElementById('navbar').style.display = '';
  document.getElementById('navbarUser').textContent = '🔑 Admin';
  document.body.classList.add('logged-in');
  renderAdminRecords();
}


// ═══════════════════════════════════════════
//  LOCAL STORAGE — STUDENT DATA PERSISTENCE
// ═══════════════════════════════════════════

function getUsers() {
  try { return JSON.parse(localStorage.getItem(USERS_KEY) || '[]'); }
  catch { return []; }
}

function getSavedAnalyses() {
  try { return JSON.parse(localStorage.getItem(RECORDS_KEY) || '[]'); }
  catch { return []; }
}

function saveToLocalStorage() {
  const record = {
    id: Date.now(),
    email: state.currentUser ? state.currentUser.email : 'unknown',
    date: new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }),
    time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
    formData: JSON.parse(JSON.stringify(state.formData)),
    results: {
      topDomain: state.results.domains[0],
      topSector: state.results.sectors[0],
      strongestLang: state.results.languages[0] || null,
      criticalGaps: state.results.skillGaps.filter(g => g.priority === 'critical').length,
      isBeginner: state.results.isBeginner
    }
  };

  const saved = getSavedAnalyses();
  saved.unshift(record);
  if (saved.length > 100) saved.length = 100;

  try {
    localStorage.setItem(RECORDS_KEY, JSON.stringify(saved));
    showToast('Analysis saved successfully', 'success');
  } catch (e) {
    showToast('Could not save — storage may be full', 'error');
  }
}


// ═══════════════════════════════════════════
//  ADMIN PANEL — VIEW ALL STUDENT RECORDS
// ═══════════════════════════════════════════

function renderAdminRecords() {
  const saved = getSavedAnalyses();
  const list = document.getElementById('adminRecordsList');
  const countEl = document.getElementById('adminStudentCount');
  const searchQuery = (document.getElementById('adminSearchInput')?.value || '').toLowerCase();

  if (!list) return;

  const filtered = searchQuery
    ? saved.filter(r => r.formData.name.toLowerCase().includes(searchQuery) || (r.email && r.email.toLowerCase().includes(searchQuery)))
    : saved;

  countEl.textContent = `${filtered.length} student record${filtered.length !== 1 ? 's' : ''} found${searchQuery ? ` for "${searchQuery}"` : ''}`;

  if (filtered.length === 0) {
    list.innerHTML = `
      <div class="full-width" style="text-align:center; color:var(--txt-muted); padding: var(--space-3xl);">
        <div style="font-size:3rem; margin-bottom:var(--space-md);">📋</div>
        <p>${searchQuery ? 'No records match your search.' : 'No student records yet. Students need to run analyses first.'}</p>
      </div>`;
    return;
  }

  list.innerHTML = filtered.map(record => {
    const domain = record.results.topDomain;
    const sector = record.results.topSector;
    const lang = record.results.strongestLang;
    const isBeg = record.results.isBeginner;

    return `
      <div class="admin-record">
        <button onclick="deleteSavedRecord(${record.id})" style="
          position:absolute; top:12px; right:12px; background:none; border:none;
          color:var(--txt-muted); cursor:pointer; font-size:1.1rem; padding:4px;
        " title="Delete this record">✕</button>

        <div style="display:flex; align-items:center; gap:var(--space-md); margin-bottom:var(--space-lg);">
          <div style="width:44px;height:44px;border-radius:50%;background:var(--grad-primary);display:flex;align-items:center;justify-content:center;color:#fff;font-size:1.3rem;">${domain ? domain.icon : '📋'}</div>
          <div>
            <div style="font-weight:700; font-size:1.1rem;">${record.formData.name}</div>
            <div style="font-size:0.8rem; color:var(--txt-muted);">${record.email || 'N/A'} · ${record.date} at ${record.time}</div>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:var(--space-sm) var(--space-lg); font-size:0.88rem;">
          <div><span style="color:var(--txt-muted);">CGPA:</span> <strong>${record.formData.cgpa || 'N/A'}</strong></div>
          <div><span style="color:var(--txt-muted);">Year:</span> <strong>${record.formData.year || 'N/A'}</strong></div>
          <div><span style="color:var(--txt-muted);">Domain:</span> <strong style="color:var(--clr-primary);">${domain ? domain.name : 'N/A'} ${domain ? '(' + domain.confidence + '%)' : ''}</strong></div>
          <div><span style="color:var(--txt-muted);">Sector:</span> <strong>${sector ? sector.name.split('(')[0].trim() : 'N/A'}</strong></div>
          <div><span style="color:var(--txt-muted);">Best Lang:</span> <strong style="color:var(--clr-accent);">${lang ? lang.name : 'None'}</strong></div>
          <div><span style="color:var(--txt-muted);">Status:</span> <strong style="color:${isBeg ? 'var(--clr-warning)' : 'var(--clr-success)'};">${isBeg ? '🌱 Beginner' : '✓ Analyzed'}</strong></div>
        </div>
      </div>
    `;
  }).join('');
}

function deleteSavedRecord(id) {
  let saved = getSavedAnalyses();
  saved = saved.filter(r => r.id !== id);
  localStorage.setItem(RECORDS_KEY, JSON.stringify(saved));
  renderAdminRecords();
  showToast('Record deleted', 'info');
}

function clearAllSaved() {
  if (confirm('Are you sure you want to delete ALL student records? This cannot be undone.')) {
    localStorage.removeItem(RECORDS_KEY);
    renderAdminRecords();
    showToast('All records cleared', 'info');
  }
}

